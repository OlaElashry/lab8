package com.example.first_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
